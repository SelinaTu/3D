#!/usr/bin/env python3
"""Read-only independent geometry audit; does not import/execute attached code."""
import ast
import csv
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
INPUT = BASE / 'input'
EPS = 1e-7
V3_SIZE = (11600, 2250, 2500)
SUBMITTED_SIZE = (12000, 2340, 2680)
CAVITIES = {
    'MC-R16': (1200, 2200, 160),
    'MC-R21': (1200, 1600, 110),
    'MC-R23': (3000, 790, 210),
}


def read_csv(name):
    with (INPUT / name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def dims_box(p, d):
    return tuple(p) + tuple(p[i] + d[i] for i in range(3))


def subtract(outer, hole):
    # Six non-overlapping slabs = the true rectangular frame material.
    x0, y0, z0, x1, y1, z1 = outer
    a, b, c, d, e, f = hole
    boxes = [(x0,y0,z0,a,y1,z1),(d,y0,z0,x1,y1,z1),
             (a,y0,z0,d,b,z1),(a,e,z0,d,y1,z1),
             (a,b,z0,d,e,c),(a,b,f,d,e,z1)]
    return [v for v in boxes if all(v[i+3]-v[i] > EPS for i in range(3))]


def separation(a, b):
    return tuple(max(a[i]-b[i+3], b[i]-a[i+3]) for i in range(3))


def item_record(r):
    p = tuple(float(r[k]) for k in ('X_mm','Y_mm','Z_mm'))
    d = tuple(float(r[k]) for k in ('长X_mm','宽Y_mm','高Z_mm'))
    q = {'id':r['实例编号'],'type':r['类型编号'],'container':r['柜号'],
         'position':p,'size':d,'pose':r['姿态'],'host':r['嵌套宿主'],
         'source':r['来源'],'box':dims_box(p,d)}
    if q['type'] in CAVITIES:
        m = ast.literal_eval(r['旋转矩阵'])
        local = CAVITIES[q['type']]
        hd = tuple(sum(abs(m[i][j])*local[j] for j in range(3)) for i in range(3))
        hp = tuple(p[i]+(d[i]-hd[i])/2 for i in range(3))
        q['hole'] = dims_box(hp, hd)
        q['solids'] = subtract(q['box'],q['hole'])
    else:
        q['solids'] = [q['box']]
    return q


items = [item_record(r) for r in read_csv('cargo.csv')]
by_id = {q['id']:q for q in items}
groups = defaultdict(list)
for q in items:
    groups[q['container']].append(q)

def bounds(size, exception=False):
    issues=[]
    for q in items:
        limits=list(size)
        if exception and q['type']=='MC-R16':
            limits[2]=max(limits[2],2560)
        over = [max(0,q['box'][i+3]-limits[i],-q['box'][i]) for i in range(3)]
        if max(over)>EPS:
            issues.append({k:q[k] for k in ('id','container','position','size','pose')} | {'overMm':over})
    return issues


collisions=[]
gap_issues=[]
for container, qs in groups.items():
    for a,b in itertools.combinations(qs,2):
        gap=0 if a['type'].startswith('GL-') and b['type'].startswith('GL-') else 5
        if max(separation(a['box'],b['box'])) >= gap-EPS:
            continue
        best = float('inf')
        collided=False
        for ab,bb in itertools.product(a['solids'],b['solids']):
            sep=separation(ab,bb)
            best=min(best,max(sep))
            if max(sep)<-EPS:
                collided=True
        detail={'container':container,'a':a['id'],'b':b['id'],
                'materialAxisSeparationMm':best,'requiredGapMm':gap}
        if collided:
            collisions.append(detail)
        elif best < gap-EPS:
            gap_issues.append(detail)

nesting=[]
nesting_authorization=[]
hole_boundary=[]
for q in items:
    if not q['host']:
        continue
    host=by_id[q['host']]
    reason=None
    if host['type']=='MC-R21' and q['source'].startswith('门窗:'):
        reason='short-frame cavity accepts accessories only; door/window child forbidden'
    elif host['type'] in ('MC-R16','MC-R23') and q['source'].startswith('门窗:') and not q['pose'].startswith('side'):
        reason='door/window in cavity must keep original width axis vertical; submitted pose is '+q['pose']
    rec={'id':q['id'],'host':q['host'],'container':q['container'],'pose':q['pose'],
         'position':q['position'],'size':q['size'],'hostType':host['type'],'childType':q['type']}
    nesting.append(rec)
    if reason:
        nesting_authorization.append(rec | {'reason':reason})
    h=host['hole']
    outside=[max(0,h[i]-q['box'][i],q['box'][i+3]-h[i+3]) for i in range(3)]
    if max(outside)>EPS:
        hole_boundary.append(rec | {'outsideHoleMm':outside})

plan=json.loads((INPUT/'plan.json').read_text())
plan_by={p['item_id']:p for p in plan['placements']}
position_discrepancies=[]
for q in items:
    pp=plan_by.get(q['id'])
    if not pp or any(abs(pp['position_u'][i]/2-q['position'][i])>EPS for i in range(3)):
        position_discrepancies.append(q['id'])

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


result={
 'method':'Independent Python standard-library audit of static CSV/JSON; rectangular cavity subtracted into non-overlapping material slabs; no attached executable code run.',
 'sourceHashes':{p.name:sha(p) for p in [INPUT/'cargo.csv',INPUT/'cavities.csv',INPUT/'nesting.csv',INPUT/'plan.json']},
 'units':{'planCoordinateUnitMm':0.5,'cargoCsvUnitMm':1,'planCsvPositionDiscrepancies':position_discrepancies},
 'container':{'submittedSizeMm':SUBMITTED_SIZE,'v3SizeMm':V3_SIZE,'submittedVolumeM3':12000*2340*2680/1e9,'v3VolumeM3':11600*2250*2500/1e9,'capacityIncreasePercent':(12000*2340*2680/(11600*2250*2500)-1)*100},
 'counts':{'items':len(items),'containers':len(groups),'nestedItems':len(nesting),
           'outOfSubmittedBounds':len(bounds(SUBMITTED_SIZE)),
           'outOfV3BoundsWithW02HeightException':len(bounds(V3_SIZE,True)),
           'cargoMaterialCollisionPairs':len(collisions),'cargoGapViolationPairs':len(gap_issues),
           'uniqueCargoInGapViolations':len({q[k] for q in gap_issues for k in ('a','b')}),
           'nestingAuthorizationViolations':len(nesting_authorization),'outsideConfirmedHole':len(hole_boundary)},
 'nestingByHostType':dict(Counter(q['hostType'] for q in nesting)),
 'nestingAuthorizationByHostType':dict(Counter(q['hostType'] for q in nesting_authorization)),
 'v3BoundaryByAxis':{axis:sum(q['overMm'][i]>EPS for q in bounds(V3_SIZE,True)) for i,axis in enumerate('XYZ')},
 'v3BoundaryMaximumOverMm':[max((q['overMm'][i] for q in bounds(V3_SIZE,True)),default=0) for i in range(3)],
 'v3BoundaryByContainer':dict(Counter(q['container'] for q in bounds(V3_SIZE,True))),
 'gapHistogramMm':dict(Counter(q['materialAxisSeparationMm'] for q in gap_issues)),
 'outOfV3Bounds':bounds(V3_SIZE,True),
 'outOfSubmittedBounds':bounds(SUBMITTED_SIZE),
 'materialCollisions':collisions,'gapViolations':gap_issues,
 'nestingAuthorizationViolations':nesting_authorization,'outsideConfirmedHole':hole_boundary,
 'scopeLimitations':['Cargo-to-cargo geometry only; wood members not included in pair counts.','No structural strength, support load, stacking count/compatibility or loading sequence certification.','The W02 2560 mm exception applies only to MC-R16; all other cargo retains 2500 mm limit.','A gap violation pair can involve nested host/child; open cavity faces have no imaginary material or boundary gap.'],
}
(BASE/'geometry-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for name,data in [('gap-violations',gap_issues),('nesting-authorization',nesting_authorization),('out-of-v3-bounds',result['outOfV3Bounds'])]:
    if data:
        with (BASE/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
counts=result['counts']
lines=['# 8 柜方案独立几何审计','',
       '本审计只解析附件静态 CSV/JSON；未运行附件 HTML/JavaScript。按真实框梁扣除已确认居中空腔，避免把合法孔内货物误判为实体相交。',
       '',f'- 货物 {len(items)} 件，{len(groups)} 柜；plan.json 的位置单位为 0.5 mm，与 cargo.csv 全量对齐，差异 {len(position_discrepancies)} 件。',
       f'- 附件净空 12000×2340×2680 mm，75.2544 m³；我方验收 11600×2250×2500 mm，65.25 m³。单柜容量增加 {result["container"]["capacityIncreasePercent"]:.4f}%。',
       f'- 附件自身净空下越界 {counts["outOfSubmittedBounds"]} 件；换成已确认净空（仅 W02 框允许高 2560 mm）越界 {counts["outOfV3BoundsWithW02HeightException"]} 件。',
       f'- 货物真实实体穿插 {len(collisions)} 对；按我方三轴 5 mm、仅玻璃架之间 0 mm 的规则，有 {len(gap_issues)} 对间距不足，涉及 {counts["uniqueCargoInGapViolations"]} 件货物。',
       f'- 其中实体直接接触（0 mm）{sum(abs(q["materialAxisSeparationMm"])<EPS for q in gap_issues)} 对，其余间隔不足 5 mm；最大越界沿 X/Y/Z 分别为 {result["v3BoundaryMaximumOverMm"]} mm。',
       f'- 嵌套共 {len(nesting)} 件，其中 {len(nesting_authorization)} 件不符合已确认孔内对象或方向：W02 框孔 {result["nestingAuthorizationByHostType"].get("MC-R16",0)} 件、W01 长框孔 {result["nestingAuthorizationByHostType"].get("MC-R23",0)} 件、W01 短框孔 {result["nestingAuthorizationByHostType"].get("MC-R21",0)} 件。',
       f'- 静态居中孔几何自身越界 {len(hole_boundary)} 件。',
       '', '## 可复核反例','']
for q in result['outOfV3Bounds'][:3]:
    lines.append(f'- 越界：{q["container"]} {q["id"]} 位置 {q["position"]}、尺寸 {q["size"]}，超原净空 {q["overMm"]} mm。')
for q in gap_issues[:3]:
    lines.append(f'- 间距：{q["container"]} {q["a"]} / {q["b"]}，实体轴间隔 {q["materialAxisSeparationMm"]} mm，应至少 {q["requiredGapMm"]} mm。')
for ht in ('MC-R16','MC-R23','MC-R21'):
    q=next(v for v in nesting_authorization if v['hostType']==ht)
    lines.append(f'- 孔内限制：{q["container"]} {q["id"]}（{q["pose"]}，{q["size"]}）放入 {q["host"]}；{q["reason"]}。')
lines += ['', '## 复算与范围','', '`python3 output/audit-eight/geometry-audit.py` 可复算；全量明细见 geometry-audit.json 及三个 CSV。', '', '本文件没有评估木架强度、顶部载荷、叠放兼容、叠层数或装入路径；几何不穿插不代表可运输。附件 validation.json 已把支承与装载顺序标为 not_applicable、运输审核为 pending。']
(BASE/'geometry-audit.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'counts':counts,'container':result['container'],'nestingAuthorizationByHostType':result['nestingAuthorizationByHostType']},ensure_ascii=False,indent=2))
