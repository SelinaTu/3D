import { readFileSync,writeFileSync } from 'node:fs'
import { loadResearchCalibration } from '../../src/core/research-calibration.ts'
import { calculateActualDimensions,orientationsFor } from '../../src/core/packing-utils.ts'
import { loadingRulesFor } from '../../src/core/loading-profile.ts'
import { createPackingSolution } from '../../src/core/solution-builder.ts'
import { validateSolution } from '../../src/core/validation.ts'
import { pairGeometryErrors,nestedInside } from '../../src/core/solid-geometry.ts'
import type {Container,Orientation} from '../../src/types/packing.ts'
const cal=loadResearchCalibration('data/reconstruction/model-v3-contract.json')
const rows=JSON.parse(readFileSync('output/audit-eight/cargo-placements.json','utf8')) as Record<string,string>[]
const source=new Map<string,typeof cal.items>()
for(const item of cal.items){const key=`${item.rawData._sourceSheet}:${item.rawData._sourceRow}`,list=source.get(key)??[];list.push(item);source.set(key,list)}
const origUnit=(id:string)=>Number(id.match(/:u(\d+)$/)?.[1]??1)
for(const list of source.values())list.sort((a,b)=>origUnit(a.id)-origUnit(b.id))
const all=rows.map(row=>{
 const unit=Number(row['实例编号'].split('-').at(-1)),item=source.get(row['来源'])?.[unit-1];if(!item)throw Error(`Unmapped ${row['实例编号']}`)
 const d={length:Number(row['长X_mm']),width:Number(row['宽Y_mm']),height:Number(row['高Z_mm'])}
 const desired:Orientation=row['姿态'].startsWith('side')?'lying':row['姿态'].startsWith('upright')?'standing':item.orientationVerticalAxes?'flat':'standing'
 const match=orientationsFor(item).filter(v=>['length','width','height'].every(k=>v.dimensions[k as keyof typeof d]===d[k as keyof typeof d])).sort((a,b)=>Number(b.orientation===desired)-Number(a.orientation===desired))[0]
 const orientation=match?.orientation??desired,rotation=match?.rotation??(row['姿态'].includes('h90')?90:0)
 return {externalId:row['实例编号'],source:row['来源'],containerId:row['柜号'],mappedId:item.id,pose:row['姿态'],variantAllowed:!!match,placed:{item,orientation,rotation,position:{x:Number(row.X_mm),y:Number(row.Y_mm),z:Number(row.Z_mm)},actualDimensions:d}}
})
writeFileSync('output/audit-eight/mapping.json',JSON.stringify(all.map(({placed,...rest})=>({...rest,position:placed.position,actualDimensions:placed.actualDimensions})),null,2))
const makeContainers=(dims:Container['dimensions'])=>[...new Set(rows.map(r=>r['柜号']))].map(id=>({id,dimensions:dims,maxWeight:cal.config.containerMaxWeight,loadingRules:loadingRulesFor(cal.items,cal.config),items:all.filter(x=>x.containerId===id).map(x=>x.placed),totalWeight:0,volumeUtilization:0,weightUtilization:0})) as Container[]
const summary:any={mapping:{total:all.length,uniqueAuthoritativeIds:new Set(all.map(x=>x.mappedId)).size,forbiddenVariants:all.filter(x=>!x.variantAllowed).map(({placed,...r})=>({...r,allowed:placed.item.allowedOrientations}))},scenarios:[]}
for(const [label,dims] of [['approved-pdf',cal.config.containerDimensions],['attachment-box-only-with-original-rules',{length:12000,width:2340,height:2680}]] as const){
 const containers=makeContainers(dims),config={...cal.config,containerDimensions:dims},solution=createPackingSolution(containers,[],'EXTERNAL-EIGHT-AUDIT',0,0),validation=validateSolution(solution,cal.items,config)
 const counts:Record<string,number>={};for(const error of validation.errors){const type=error.includes('超出集装箱边界')?'boundary':error.includes('间隙')?'clearance':error.includes('空腔')?'cavity':error.includes('支撑')||error.includes('承托')||error.includes('重心')?'support':error.includes('承重')||error.includes('重量')||error.includes('载荷')?'load':error.includes('错位')?'offset':error.includes('叠放')?'stacking':error.includes('方向')?'orientation':'other';counts[type]=(counts[type]??0)+1}
 const pairErrors:unknown[]=[],nested:unknown[]=[],bounds:unknown[]=[]
 for(const c of containers){for(let i=0;i<c.items.length;i++){const a=c.items[i],expected=calculateActualDimensions(a.item.dimensions,a.orientation,a.rotation,a.item.orientationVerticalAxes),maxHeight=a.item.rawData._sourceSheet==='门窗'&&a.item.rawData._sourceRow===16?Math.max(dims.height,2560):dims.height
 if(a.position.x+expected.length>dims.length||a.position.y+expected.width>dims.width||a.position.z+expected.height>maxHeight)bounds.push({container:c.id,id:a.item.id,externalId:all.find(x=>x.mappedId===a.item.id)!.externalId,position:a.position,actualDimensions:expected,end:{x:a.position.x+expected.length,y:a.position.y+expected.width,z:a.position.z+expected.height},allowedHeight:maxHeight})
 for(let j=i+1;j<c.items.length;j++){const b=c.items[j],errors=pairGeometryErrors(a,b,c);if(errors.length)pairErrors.push({container:c.id,a:a.item.id,b:b.item.id,errors});if(nestedInside(a,b)||nestedInside(b,a))nested.push({container:c.id,a:a.item.id,b:b.item.id})}}
 }
 const detail={label,dimensions:dims,woodIncluded:false,woodExclusionReason:'The approved v3 has no newly engineered wood structures; attachment wood is separately reviewed, not silently validated by the cargo-only model.',validation,errorCounts:counts,boundaryViolations:bounds,pairGeometryErrorCount:pairErrors.length,pairGeometryErrors:pairErrors,nestedCount:nested.length}
 writeFileSync(`output/audit-eight/${label}-validation.json`,JSON.stringify(detail,null,2));summary.scenarios.push({label,valid:validation.valid,totalErrors:validation.errors.length,errorCounts:counts,boundaryCount:bounds.length,pairGeometryErrorCount:pairErrors.length,nestedCount:nested.length,examples:validation.errors.slice(0,12)})
}
writeFileSync('output/audit-eight/recheck-summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2))
