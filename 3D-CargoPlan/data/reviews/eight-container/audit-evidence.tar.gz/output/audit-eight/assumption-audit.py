"""Read only audit of user supplied data. Does not execute attached code."""
from pathlib import Path
import json, csv, collections, hashlib, re
root=Path(__file__).resolve().parent
src=root/'input'
p=json.loads((src/'plan.json').read_text())
v=json.loads((src/'validation.json').read_text())
result=json.loads((src/'result.json').read_text())
html=(src/'report.html').read_text()
e=json.loads(re.search(r'<script[^>]+id="packing-3d-data"[^>]*>(.*?)</script>',html,re.S).group(1))
with (src/'cargo.csv').open(encoding='utf-8-sig') as f:
    cargo={x['实例编号']:x for x in csv.DictReader(f)}
placements={x['item_id']:x for x in p['placements']}
relations=p['nesting_relations']
byhost={}
for prefix in ['MC-R16','MC-R21','MC-R23']:
    rs=[x for x in relations if x['host_id'].startswith(prefix)]
    doors=[x for x in rs if x['child_id'].startswith('MC-')]
    byhost[prefix]={'relations':len(rs),'door_children':len(doors),'aux_children':len(rs)-len(doors),
                    'door_poses':dict(collections.Counter(placements[x['child_id']]['pose_id'] for x in doors))}
wrong_orientation=[x for x in relations if x['child_id'].startswith('MC-') and x['host_id'].startswith(('MC-R16','MC-R23')) and not placements[x['child_id']]['pose_id'].startswith('side')]
wrong_category=[x for x in relations if x['host_id'].startswith('MC-R21') and x['child_id'].startswith('MC-')]
wrong_unique=set(x['child_id'] for x in wrong_orientation+wrong_category)
limits=[]
for c in e['containers']:
    objects=[o for o in c['objects'] if o['id'] in cargo]
    for lo in objects:
        if lo['type_id'] not in ['MC-R09','MC-R14','MC-R15']: continue
        z=lo['position'][2]+lo['size'][2]
        for up in objects:
            if up['id']==lo['id'] or float(cargo[up['id']]['质量_g'])<=5000:continue
            touch=any(abs(a['position'][2]+a['size'][2]-z)<1e-9 and abs(b['position'][2]-z)<1e-9 and all(min(a['position'][i]+a['size'][i],b['position'][i]+b['size'][i])-max(a['position'][i],b['position'][i])>1e-9 for i in [0,1]) for a in lo['solids'] for b in up['solids'])
            if touch:
                limits.append({'container':c['id'],'lower_id':lo['id'],'upper_id':up['id'],'upper_mass_kg':float(cargo[up['id']]['质量_g'])/1000,'per_upper_limit_kg':5,'contact_z_mm':z})
flat_overstacks=[]
for prefix,max_count in [('MC-R23',10),('MC-R20',10),('MC-R17',10),('MC-R22',6)]:
    groups=collections.defaultdict(list)
    for x in cargo.values():
        if x['类型编号']==prefix and x['姿态'].startswith('flat'):
            groups[(x['柜号'],x['X_mm'],x['Y_mm'],x['姿态'])].append(x)
    for key,rs in groups.items():
        rs.sort(key=lambda x:float(x['Z_mm']))
        chain=[]
        for x in rs:
            if chain and abs(float(chain[-1]['Z_mm'])+float(chain[-1]['高Z_mm'])-float(x['Z_mm']))>1e-9:
                if len(chain)>max_count:flat_overstacks.append({'container':key[0],'type_id':prefix,'count':len(chain),'limit':max_count,'item_ids':[z['实例编号'] for z in chain]})
                chain=[]
            chain.append(x)
        if len(chain)>max_count:flat_overstacks.append({'container':key[0],'type_id':prefix,'count':len(chain),'limit':max_count,'item_ids':[z['实例编号'] for z in chain]})
examples=[
 {'issue':'wrong_cavity_axis','rule':'W02孔内门窗必须原宽轴竖直，禁止窗面内90度旋转','item':cargo['MC-R06-030'],'host':cargo['MC-R16-030'],'actual_vertical_original_axis':'length','actual_vertical_mm':1330,'required_vertical_original_axis':'width','required_vertical_mm':1030},
 {'issue':'flat_door_in_long_frame','rule':'长框孔内门窗必须侧放，原宽轴竖直','item':cargo['MC-R08-131'],'host':cargo['MC-R23-041']},
 {'issue':'short_frame_wrong_child_category','rule':'W01短框孔内仅允许辅材','item':cargo['MC-R22-022'],'host':cargo['MC-R21-022']},
 {'issue':'single_top_item_81kg_exceeds_5kg','lower':cargo['MC-R14-023'],'upper':cargo['MC-R14-024'],'limit_kg':5},
 {'issue':'single_top_item_74kg_exceeds_5kg','lower':cargo['MC-R15-012'],'upper':cargo['MC-R15-013'],'limit_kg':5},
]
gaps=[
 {'axis':'x','first':'AC-R30-001','second':'AC-R29-001','first_min_mm':0,'first_size_mm':1200,'second_min_mm':1200,'gap_mm':0,'required_mm':5},
 {'axis':'y','first':'MC-R16-030','second':'MC-R16-068','first_min_mm':1420,'first_size_mm':160,'second_min_mm':1580,'gap_mm':0,'required_mm':5},
 {'axis':'z','first':'MC-R23-041','second':'MC-R23-001','first_min_mm':0,'first_size_mm':210,'second_min_mm':210,'gap_mm':0,'required_mm':5},
 {'axis':'cavity_x_wall','child':'MC-R08-131','host':'MC-R23-041','child_x_mm':1800,'cavity_x_mm':1800,'gap_mm':0,'required_mm':5},
]
wood=p['wood_parts']
summary={
 'scope':'Static data audit only. No attachment HTML or code executed. Explicit nesting relations counted separately from independently inferred intersections.',
 'hashes':{name:hashlib.sha256((src/name).read_bytes()).hexdigest() for name in ['plan.json','validation.json','cargo.csv','report.html']},
 'model_contract':{'path':'data/reconstruction/model-v3-contract.json','sha256':hashlib.sha256(Path('data/reconstruction/model-v3-contract.json').read_bytes()).hexdigest()},
 'attachment_validation':{k:value for k,value in v.items() if k!='issues'},
 'attachment_scope_warnings':[x for x in v['issues'] if x['code'] in ['GEOMETRY_SCOPE','GEOMETRIC_WOOD_SCOPE','ASSUMED_CAVITY_SCOPE','ASSUMED_CAVITY_POSITION']],
 'attachment_result':{k:result[k] for k in ['termination','proof_status','lower_bound_bins','unplaced_item_ids']},
 'counts':{'cargo':len(p['placements']),'nesting_relations':len(relations),'unique_nested_children':len(set(x['child_id'] for x in relations)),'unique_hosts':len(set(x['host_id'] for x in relations)),
           'nested_doors':sum(x['child_id'].startswith('MC-') for x in relations),'nested_aux':sum(x['child_id'].startswith('AC-') for x in relations),
           'explicit_wrong_orientation_doors_in_long_or_w02':len(wrong_orientation),'explicit_wrong_category_doors_in_short':len(wrong_category),'unique_explicit_nesting_violations':len(wrong_unique),
           'direct_top5_limit_violation_pairs':len(limits),'direct_top5_limit_violation_unique_uppers':len(set(x['upper_id'] for x in limits))},
 'nesting_by_host_type':byhost,'explicit_wrong_orientation_relations':wrong_orientation,'explicit_wrong_category_relations':wrong_category,
 'cargo_rule_examples':examples,'zero_gap_examples':gaps,'direct_top5_limit_violations':limits,'flat_stack_count_violations':flat_overstacks,
 'cavity_geometry_comparison':'All three cavity axis maps, centered offsets and sizes shown in cavities.csv agree with frozen v3 normalized geometry. The major cavity differences are authorization, orientation and internal clearance; do not falsely claim a different cavity size or center.',
 'wood':{'parts':len(wood),'assemblies':len(p['support_assemblies']),'mass_null_count':sum(x['mass_g'] is None for x in wood),'net_volume_m3':sum(x['net_size_u'][0]*x['net_size_u'][1]*x['net_size_u'][2] for x in wood)/8/1e9,
          'kind_counts':dict(collections.Counter(x['kind'] for x in wood)),'material_counts':dict(collections.Counter(x['material_id'] for x in wood)),'connection_spec_counts':dict(collections.Counter(x['connection_spec_id'] for x in wood)),
          'first_example':wood[0],'model_difference':'v3 retains no added physical spacers/materials (user: PDF没有就不用). Attachment adds 305 geometric support assemblies with 2604 parts; material grades, strength, connections, self weight and lateral stability are explicitly unconfirmed.'},
 'conclusion':'This is an 8-container geometric layout under a larger container and relaxed authorization/gap/load/support model, not a verified 8-container solution to the frozen v3 problem. The audit does not prove that eight bins are impossible under v3.'
}
(root/'assumption-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
md=f'''# 8柜附件规则与假设审核

采用静态读取 JSON/CSV/HTML 内嵌数据；未执行附件 HTML 或代码。对照冻结 v3 合同。仅审核附件模型口径与规则；不将“8柜”视作同题已通过，也不据此断言同题8柜不可能。

## 附件自己的验收范围

`validation.json` 自报 `planning_mode=geometry`，清单与几何 `passed`，承托模型及装入顺序 `not_applicable`，运输复核 `pending`。`result.json` 为 `proof_status=feasible_only`，不是全局最优证明。

原文 `GEOMETRY_SCOPE`：未校验载重、叠放载荷/类别/层数、受力、支承稳定、地板承载、重心及完整装入路径；未给保护间隙时采用配置0。`ASSUMED_CAVITY_SCOPE`：忽略内件类别、空腔保护间距和进出路径。因此“geometry passed”不等于符合原表、原PDF及用户确认规则。

## 空腔：居中尺寸一致，使用规则被放宽

三种孔位的归一尺寸、居中偏移与 v3 相同：W02原轴孔1200×2200×160，偏移915/180/0；长框3000×790×210，偏移1800/100/0；短框1200×1600×110，偏移447/37/0。不能将差异归因于孔尺寸造大或孔位移位。

显式 `nesting_relations` 共599条、599个不同内件（506门窗+93辅材），涉及192宿主：

| 宿主 | 门窗内件 | 辅材内件 | 门窗姿态 |
|---|---:|---:|---|
| W02 MC-R16 | 184 | 2 | 92 upright、92 side |
| W01长框 MC-R23 | 276 | 91 | 253 flat、23 side |
| W01短框 MC-R21 | 46 | 0 | 多种姿态 |

在显式关系口径中，345门窗违反W02/长框孔内必须侧放，另外46扇进入只允许辅材的短框孔，合计391个不同内件不符合当前空腔规则。独立几何相交程序可能找到额外未声明关系，不与此599条声明口径混用。

- 柜001 `MC-R06-030`（W04）在 `MC-R16-030` 的W02孔，实际1030×120×1330，Z=180，竖直原长1330；用户已确认应原宽1030竖直，不允许这种窗面90度旋转。此类W04共92件。
- 柜001 `MC-R08-131`（W05）平放530×530×120在 `MC-R23-041` 长框孔；孔内门窗原要求侧放，原宽530竖直。
- 柜001 `MC-R22-022`（W01扇100kg）平放于 `MC-R21-022` 短框孔；短框孔原表仅允许辅材，46扇全部越过类别限制。

## 三轴5mm间隙未执行

可复查的零间隙：

| 方向 | 两件货物 | 几何证据 | 当前要求 |
|---|---|---|---|
| X | AC-R30-001 → AC-R29-001 | 前件X=0、长1200，后件X=1200，间隔0 | 5mm |
| Y | MC-R16-030 → MC-R16-068 | 前件Y=1420、宽160，后件Y=1580，间隔0 | 5mm |
| Z | MC-R23-041 → MC-R23-001 | 前件Z=0、高210，后件Z=210，间隔0 | 5mm |
| 孔内壁X | MC-R08-131 → MC-R23-041 | 内件X=孔左壁X=1800，侧壁间隔0 | 5mm |

以上均非玻璃架与玻璃架的0mm特例。

## 原表载荷和层数限制确有突破

不仅是“尚未检查”：可以从货物实体的水平接触面及重量证明现有摆放不符合限制。按附件内嵌实体几何逐对检查，顶部单件上限5kg的W07/W11/W12，发现129对直接接触关系（涉及40个不同上件）上件自重超过5kg；清单见JSON。

- 柜003 W11 `MC-R14-023`（Z1645、高150）上同XY直接叠 `MC-R14-024`（Z1795），上件81kg，超过5kg。
- 柜008 W12 `MC-R15-012`（Z2230、高150）上同XY叠 `MC-R15-013`（Z2380），上件74kg，超过5kg。
- 柜002、柜003各有两柱W01长框，同XY从Z0以210mm连续叠12件；原表平放总数≤10。至少4柱违规。
- 柜008 W06扇在XY=(6550,220)从Z220到1760，连续15件平放130kg扇；原表平放总数≤10。另一柱XY=(9204.5,220)连续13件，同样违规。

加回5mm或少量改坐标不会消除81kg>5kg、74kg>5kg与12/15件>10件这些限制，必须重新分配与重排。

## 额外木架改变了题目且尚无工程校验

新增305木架、2604木件：1989立柱、508板、107垫片，净木材体积 **4.12783989925m³**。2604件质量全为null，全部连接说明为“几何草案，连接及强度未校验”。材料分为1989“木方（等级未确认）”、508“木板（等级未确认）”、107“木板刨薄（等级未确认）”。

第一件 `几何木架-MC-R18-001-0001` 为50×50×192mm木柱，从地面穿入长框孔，为上层MC-R18-001补平。附件明确不确认木材等级、强度、连接、自重、抗侧倾；未含锯缝及加工余量。当前v3用户约定“参考PDF如果没有就不用”，无新增实体隔垫，保留几何投影载荷假设。因此不能把这些木架视作已确认的承压、荷载转移或运输支撑方案。

## 审核结论

附件8柜并非单纯使用更强算法解出了同一问题；它同时采用更大净空、0mm默认缝隙、放宽孔内方向/类别，且未执行原表顶部重量和叠放层数，也添加了未定级、未计重、未做连接/强度验算的木架。它仍有可借鉴的几何布局与孔内空间组织，需恢复同一验收口径后再优化及验证。数据和全部具体反例保存在 `assumption-audit.json`。
'''
(root/'assumption-audit.md').write_text(md)
print(json.dumps({'counts':summary['counts'],'by_host':byhost,'overstack_count':len(flat_overstacks),'wood_volume':summary['wood']['net_volume_m3']},ensure_ascii=False,indent=2))
