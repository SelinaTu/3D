# 8 柜方案独立几何审计

本审计只解析附件静态 CSV/JSON；未运行附件 HTML/JavaScript。按真实框梁扣除已确认居中空腔，避免把合法孔内货物误判为实体相交。

- 货物 1371 件，8 柜；plan.json 的位置单位为 0.5 mm，与 cargo.csv 全量对齐，差异 0 件。
- 附件净空 12000×2340×2680 mm，75.2544 m³；我方验收 11600×2250×2500 mm，65.25 m³。单柜容量增加 15.3324%。
- 附件自身净空下越界 0 件；换成已确认净空（仅 W02 框允许高 2560 mm）越界 289 件。
- 货物真实实体穿插 0 对；按我方三轴 5 mm、仅玻璃架之间 0 mm 的规则，有 5339 对间距不足，涉及 1371 件货物。
- 其中实体直接接触（0 mm）5313 对，其余间隔不足 5 mm；最大越界沿 X/Y/Z 分别为 [392.0, 90.0, 180.0] mm。
- 嵌套共 599 件，其中 391 件不符合已确认孔内对象或方向：W02 框孔 92 件、W01 长框孔 253 件、W01 短框孔 46 件。
- 静态居中孔几何自身越界 0 件。

## 可复核反例

- 越界：柜001 AC-R15-001 位置 (9630.0, 2094.0, 2430.0)、尺寸 (280.0, 230.0, 230.0)，超原净空 [0, 74.0, 160.0] mm。
- 越界：柜001 AC-R15-002 位置 (9910.0, 2094.0, 2430.0)、尺寸 (280.0, 230.0, 230.0)，超原净空 [0, 74.0, 160.0] mm。
- 越界：柜001 AC-R15-003 位置 (10190.0, 2094.0, 2430.0)、尺寸 (280.0, 230.0, 230.0)，超原净空 [0, 74.0, 160.0] mm。
- 间距：柜001 AC-R05-001 / AC-R05-002，实体轴间隔 0.0 mm，应至少 5 mm。
- 间距：柜001 AC-R05-001 / AC-R16-003，实体轴间隔 0.0 mm，应至少 5 mm。
- 间距：柜001 AC-R05-001 / AC-R18-003，实体轴间隔 0.0 mm，应至少 5 mm。
- 孔内限制：柜001 MC-R06-024（upright，(1030.0, 120.0, 1330.0)）放入 MC-R16-024；door/window in cavity must keep original width axis vertical; submitted pose is upright。
- 孔内限制：柜001 MC-R08-101（flat，(530.0, 530.0, 120.0)）放入 MC-R23-035；door/window in cavity must keep original width axis vertical; submitted pose is flat。
- 孔内限制：柜001 MC-R22-022（flat-h90，(1060.0, 1590.0, 110.0)）放入 MC-R21-022；short-frame cavity accepts accessories only; door/window child forbidden。

## 复算与范围

`python3 output/audit-eight/geometry-audit.py` 可复算；全量明细见 geometry-audit.json 及三个 CSV。

本文件没有评估木架强度、顶部载荷、叠放兼容、叠层数或装入路径；几何不穿插不代表可运输。附件 validation.json 已把支承与装载顺序标为 not_applicable、运输审核为 pending。
